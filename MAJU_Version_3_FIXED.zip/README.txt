MAJU VERSION 3 — SIMPLE ONLINE STORE

FILES
- index.html = customer store
- admin.html = dashboard
- store.js = products/settings/order storage

HOW TO USE
1. Open index.html to view the store.
2. Open admin.html to manage the store.
3. Dashboard PIN starts as 1234.
4. In Settings, enter your WhatsApp number in international format, for example 27821234567.
5. Add/edit products, prices, stock and pictures.
6. Customers add products to cart and click "Order on WhatsApp".

IMPORTANT
This Version 3 is a simple browser-based store. Product data, settings and orders are stored in the browser's localStorage. That means the dashboard is not a real cloud database and changes are normally only available on the same browser/device.

For a fully public production store where you can log into the dashboard from any phone/computer, the next step is connecting MAJU to a hosted database, secure authentication and image storage.

PHONE FIX: index.html and admin.html are now self-contained, so the dashboard login works when opened directly from a phone/file manager.
